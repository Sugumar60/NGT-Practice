package com.capgemini.app;

import java.util.Arrays;
import java.util.List;

import com.capgemini.stream.Filter;
import com.capgemini.stream.Mapper;

public class StreamMain {

	public static void main(String[] args) {
		
		List<String> listOfNames = Arrays.asList("aaryanna","aayanna","airianna","alassandra","allannah",
				"allessandra","allianna","allyanna","anastaisa","anastashia","anastasia","annabella","annabelle","annebelle");
		listOfNames.stream().filter(Filter.nameStartingWithPrefix("ana")).map(Mapper.getDistinctCharacterCount()).forEach(System.out::println);
		
	}

}
