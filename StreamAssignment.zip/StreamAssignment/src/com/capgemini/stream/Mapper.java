package com.capgemini.stream;

import java.util.function.Function;

import com.capgemini.model.CharactersCount;

public class Mapper {

	public static Function<String, CharactersCount> getDistinctCharacterCount(){
		return name -> {
			long count = name.chars().distinct().count();
			return new CharactersCount(name, count);	
		};		
	}
}
