package com.capgemini.model;

public class CharactersCount {
	
	private String name;
	private long distinctCharacterCount;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getDistinctCharacterCount() {
		return distinctCharacterCount;
	}
	public void setDistinctCharacterCount(long distinctCharacterCount) {
		this.distinctCharacterCount = distinctCharacterCount;
	}
	
	public CharactersCount(String name, long distinctCharacterCount) {
		super();
		this.name = name;
		this.distinctCharacterCount = distinctCharacterCount;
	}
	public CharactersCount() {
		super();
	}
	
	@Override
	public String toString() {
		return "\"" + name + "\"" +" has " + distinctCharacterCount + " distinct characters.";
	}
	
}
