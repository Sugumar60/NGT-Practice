package com.xyzbank.dao;
import java.sql.*;
/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;*/

import com.xyzbank.model.Account;
import com.xyzbank.model.Loan;

public class BankDAO {
	
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	double amount = 0.0;
	
	public void createAccount(Account acc)  {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
//			Statement stmt = conn.createStatement();
//			stmt.execute("CREATE TABLE account("
//					+ "accountId VARCHAR(12) PRIMARY KEY,"
//					+ "accountName VARCHAR(30) NOT NULL,"
//					+ "address VARCHAR(200),"
//					+ "depositAmount NUMBER,"
//					+ "loanId VARCHAR(10),"
//					+ "loanAmount NUMBER,"
//					+ "loanType VARCHAR(10)"
//					+ ")");
			ps = conn.prepareStatement("INSERT INTO account (accountId,accountName,address,depositAmount)VALUES(?,?,?,?)");
			ps.setString(1, acc.getAccountId());
			ps.setString(2, acc.getAccountName());
			ps.setString(3, acc.getAddress());
			ps.setDouble(4, acc.getDepositAmount());
//			ps.setString(5, acc.getLoan().getLoanId());
//			ps.setDouble(6, acc.getLoan().getLoanAmount());
//			ps.setString(7, acc.getLoan().getLoanType().toString());
			ps.execute();
			int result = ps.executeUpdate();
			if(result>0)
				System.out.println("Account created Successfully");
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public Account getDetails(String id, Account accounts[]) throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
		    ps = conn.prepareStatement("SELECT * FROM account WHERE accountId = ?");
		    ps.setString(1, id);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;		
	}
	
	public void getLoan(String accId, Loan loan) throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
		    ps = conn.prepareStatement("UPDATE account SET loanId = ? WHERE accountId = ?");
		    ps.setString(1, loan.getLoanId());
		    ps.setString(2, accId);
		    ps.executeUpdate();
		    ps = conn.prepareStatement("UPDATE account SET loanAmount = ? WHERE accountId = ?");
		    ps.setDouble(1, loan.getLoanAmount());
		    ps.setString(2, accId);
		    ps.executeUpdate();
		    ps = conn.prepareStatement("UPDATE account SET loanType = ? WHERE accountId = ?");
		    ps.setString(1, loan.getLoanType().toString());
		    ps.setString(2, accId);
		    ps.executeUpdate();
		    ps = conn.prepareStatement("SELECT depositAmount FROM account WHERE accountId = ?");
		    ps.setString(1, accId);
		    rs = ps.executeQuery();
		    rs.next();
		    amount = rs.getDouble(1) +  loan.getLoanAmount();
		    ps = conn.prepareStatement("UPDATE account SET depositAmount = ? WHERE accountId = ?");
		    ps.setDouble(1, amount);
		    ps.setString(2, accId);
		    ps.executeUpdate();
		    System.out.println("Loan Amount credited to your Account.");
		    System.out.println("Your new Account balance is " + amount);
		    
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}   
	}
	
	public void showLoanDetails(String accId, String loanId) throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
			ps = conn.prepareStatement("SELECT accountName,loanId,loanType,loanAmount FROM account WHERE loanId = ? AND accountId = ?");
			ps.setString(1, loanId);
			ps.setString(2, accId);
			rs = ps.executeQuery();
			rs.next();
			System.out.println("=========================\nLoan Details\n=========================");
			System.out.println("Loan ID      : " + rs.getString(2));
			System.out.println("Account Name : " + rs.getString(1));
			System.out.println("Loan Amount  : " + rs.getDouble(4));
			System.out.println("Loan Type    : " + rs.getString(3));
			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  
		
	}
	
	public double depositAmount(String accId, double damt) throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
		    ps = conn.prepareStatement("SELECT depositAmount FROM account WHERE accountId = ?");
		    ps.setString(1, accId);
		    rs = ps.executeQuery();
		    rs.next();
		    amount = rs.getDouble(1) +  damt;
		    ps = conn.prepareStatement("UPDATE account SET depositAmount = ? WHERE accountId = ?");
		    ps.setDouble(1, amount);
		    ps.setString(2, accId);
		    ps.executeUpdate();
		    conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return  amount;
	}
	
	public double withdrawAmount(String accId, double wamt) throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
		    ps = conn.prepareStatement("SELECT depositAmount FROM account WHERE accountId = ?");
		    ps.setString(1, accId);
		    rs = ps.executeQuery();
		    rs.next();
		    double oldbal = rs.getDouble(1);
		    if(oldbal >= wamt)
		    	amount = oldbal -  wamt;
		    else {
		    	System.out.println("Insufficiant balance");
		    	System.out.println("Your balance amount is " + oldbal);
		    }
		    ps = conn.prepareStatement("UPDATE account SET depositAmount = ? WHERE accountId = ?");
		    ps.setDouble(1, amount);
		    ps.setString(2, accId);
		    ps.executeUpdate();
		    conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return amount;
	}
	
	public void payLoan(String loanId,  String accId, double amt) throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
			ps = conn.prepareStatement("SELECT depositAmount From account WHERE accountId = ?");
			ps.setString(1, accId);
			rs = ps.executeQuery();
			rs.next();
			double currentBalance = rs.getDouble(1);
			ps = conn.prepareStatement("SELECT loanAmount FROM account WHERE accountId = ? AND loanId = ?");
		    ps.setString(1, accId);
		    ps.setString(2, loanId);
		    rs = ps.executeQuery();
		    rs.next();
		    double loanAmount = rs.getDouble(1);
			if((currentBalance >= amt) && (amt <= loanAmount)) {
				double amount = currentBalance - amt;
				loanAmount -= amt;
				ps = conn.prepareStatement("UPDATE account SET depositAmount = ? WHERE accountId = ?");
				ps.setDouble(1, amount);
				ps.setString(2, accId);
				ps.executeUpdate();
				ps = conn.prepareStatement("UPDATE account SET loanAmount = ? WHERE accountId = ? AND loanId = ?");
				ps.setDouble(1, loanAmount);
				ps.setString(2, accId);
				ps.setString(3, loanId);
				ps.executeUpdate();
				System.out.println("Amount debited from your account.");
			    System.out.println("Your current balance is Rs." + amount);
			    System.out.println("Still you need to pay Rs." + loanAmount);
			}
			else
				System.out.println("Not a valid amount.");
		    conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

	public void showAccountDetails(String accId) throws SQLException{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
		    ps = conn.prepareStatement("SELECT accountId,accountName,address,depositAmount FROM account WHERE accountId = ?");
		    ps.setString(1, accId);
		    rs = ps.executeQuery();
		    rs.next();
		    System.out.println("====================== \nAccount Details \n======================");
		    System.out.println("Account Id     : " + rs.getString(1));
		    System.out.println("Account Name   : " + rs.getString(2));
		    System.out.println("Adress         : " + rs.getString(3));
		    System.out.println("Account Balance: " + rs.getDouble(4));
		    conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}


}
