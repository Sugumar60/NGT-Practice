package com.xyzbank.dao;

import com.xyzbank.model.Account;
import com.xyzbank.model.Loan;

public interface IBankDAO {
	
	public void getLoan(double lAmt, double oldBal, Account a);
	public void showLoanDetails(Loan l);
	public double depositAmount(double damt, double oldbal);
	public double withdrawAmount(double wamt, double oldbal);
	public void payLoan(String loanId,  String accId, double amt);
}
