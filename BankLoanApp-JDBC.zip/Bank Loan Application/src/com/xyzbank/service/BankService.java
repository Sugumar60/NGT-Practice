package com.xyzbank.service;

import java.sql.SQLException;

import com.xyzbank.dao.BankDAO;
import com.xyzbank.model.Account;
import com.xyzbank.model.Loan;

public class BankService implements IBankService{
	
	BankDAO dao = new BankDAO();
	
	//validation
	public boolean validateAccountId(String id) {
		String regexId = "^[0-9]{7}[-]{1}[A-Z]{4}$";
		return id.matches(regexId);
	}
	public boolean validateName(String fname) {
		String regexName = "^[A-Z]{1}[A-Za-z]{2,25}$";
		return fname.matches(regexName);
	}
	
	//Account
	public void showAccountDetails(String accId) throws SQLException {
		dao.showAccountDetails(accId);		
	}
	
	public void createAccount(Account acc) throws Exception {
		dao.createAccount(acc);
	}
	

	//Loan
	public void getLoan(String accId, Loan loan) throws SQLException {
		dao.getLoan(accId, loan);	
	}
	
	public void showLoanDetails(String accId, String loanId) throws SQLException {
		dao.showLoanDetails(accId, loanId);	
	}
	
	//Transaction
	public double depositAmount(String accId, double damt) throws SQLException {
		return dao.depositAmount(accId, damt);
	}
	
	public double withdrawAmount(String accId, double wamt) throws SQLException {
		return dao.withdrawAmount(accId, wamt);
	}

	public void payLoan(String loanId,  String accId, double amt) throws SQLException {
		dao.payLoan(loanId, accId, amt);
	}
		
}
