package com.xyzbank.service;


import java.sql.SQLException;

import com.xyzbank.model.Loan;

public interface IBankService {
	public void getLoan(String accId, Loan loan) throws SQLException;
	public void showLoanDetails(String accId, String loanId) throws SQLException;
	public double depositAmount(String accId, double damt) throws SQLException;
	public double withdrawAmount(String accId, double wamt) throws SQLException;
	public void payLoan(String loanId,  String accId, double amt) throws SQLException;
	public void showAccountDetails(String accId) throws SQLException;
}
