package com.xyzbank.ui;

import java.util.Scanner;

import com.xyzbank.model.Account;
import com.xyzbank.model.Loan;
import com.xyzbank.model.LoanType;
import com.xyzbank.model.Transaction;
import com.xyzbank.service.BankService;

public class BankMain {
	
	public static void main(String[] args) throws Exception {
		BankService service = new BankService();
		Account account = new Account();
		Loan loan= new Loan();
		Transaction transaction = new Transaction();
		Scanner sc = new Scanner(System.in);
		double damt;
		double wamt;
		double amt;
		String accId;
		String loanId;
		while(true) {
			System.out.println();
			System.out.println();
			System.out.println("CHOOSE YOUR OPTION:");
			System.out.println("1. Create Account");
			System.out.println("2. Deposit Amount");
			System.out.println("3. Withdraw Amount");
			System.out.println("4. Show Account details");
			System.out.println("5. Apply Loan");
			System.out.println("6. Pay Loan");
			System.out.println("7. Show loan Details");
			System.out.println("8. Exit");
			int option = sc.nextInt();
			
		switch(option) {
		
		case 1:
			Account acc = new Account();
			System.out.println("Enter your Account ID(Eg:[1234567-ABCD]:");
			String id = sc.next();
			if(service.validateAccountId(id))
				acc.setAccountId(id);
			else {
				System.out.println("Enter a valid account id");
				break;
			}
			System.out.println("Enter your Name(First letter Should be in Upper case):");
			String name = sc.next();
			if(service.validateName(name))
				acc.setAccountName(name);
			else {
				System.out.println("Enter a valid name.");
				break;
			}
			System.out.println("Enter your Address:");
			acc.setAddress(sc.next());
			System.out.println("Enter Deposit Amount:");
			acc.setDepositAmount(sc.nextDouble());
			service.createAccount(acc);
			System.out.println("Your Account has successfully created");
			break;
			
		case 2:
			System.out.println("Enter your Account Id:");
			accId =  sc.next();
			System.out.println("Enter your deposit Amount:");
			damt = sc.nextDouble();
			amt = transaction.depositAmount(accId, damt);
			System.out.println("Deposited Successfully!! \nYour new balance is " + amt);
			break;
		
		case 3:	
			System.out.println("Enter your Account Id:");
			accId =  sc.next();
			System.out.println("Enter Amount to be Withdrawal:");
			wamt = sc.nextDouble();
			amt = transaction.withdrawAmount(accId, wamt);
			System.out.println("Withdrawn Successfully!! \nYour new balance is " + amt);
			break;
		
		case 4:
			System.out.println("Enter your Account Id:");
			accId = sc.next();
			account.showDetails(accId);
			break;
			
		case 5:
			System.out.println("Enter your Account Id:");
			accId = sc.next();
			Loan l = new Loan();
			System.out.println("Enter Loan Id:");
			String lId = sc.next();
			l.setLoanId(lId);
			System.out.println("Select your Loan Type \n1) House\n2) Education \n3) Car \n4) Others");
			switch (sc.nextInt()) {
			case 1:
				l.setLoanType(LoanType.HOUSE);
				break;
			case 2:
				l.setLoanType(LoanType.EDUCATION);
				break;
			case 3:
				l.setLoanType(LoanType.CAR);
				break;
			case 4:
				l.setLoanType(LoanType.OTHERS);
				break;	
			default:
				System.out.println("Select a valid action.");
				break;
			}		
			System.out.println("Enter Loan Amount:");
			l.setLoanAmount(sc.nextDouble());
			l.getLoan(accId, l);
			break;
			
		case 6:
			System.out.println("Enter your Account Id: ");
			accId = sc.next();
			System.out.println("Enter your Loan Id:");
			loanId = sc.next();
			System.out.println("Enter the amount you want to repay:");
			amt = sc.nextDouble();
			transaction.payLoan(loanId, accId, amt);
			break;
		
		case 7:
			System.out.println("Enter your Account Id: ");
			accId = sc.next();
			System.out.println("Enter Loan Id:");
			loanId = sc.next();
			loan.showLoanDetails(accId, loanId);
			break;
			
		case 8:
			System.out.println("Thank you for using our Application");
			sc.close();
			System.exit(0);
			
		default:
			System.out.println("Choose the proper action.");
		}
	
	
	}
	}		
}
