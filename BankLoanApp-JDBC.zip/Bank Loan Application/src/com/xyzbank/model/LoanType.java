package com.xyzbank.model;

public enum LoanType {
	HOUSE,
	EDUCATION,
	CAR,
	OTHERS
}
