package com.xyzbank.model;

import java.sql.SQLException;

import com.xyzbank.service.BankService;

public class Loan extends Account {
	
	private String loanId;
	private LoanType loanType;
	private double loanAmount;
	public double amount;
	BankService service = new BankService();
	public String getLoanId() {
		return loanId;
	}
	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}
	public LoanType getLoanType() {
		return loanType;
	}
	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	
		
	public Loan() {
		super();
	}
	public Loan(String loanId, LoanType loanType, double loanAmount) {
		this.loanId = loanId;
		this.loanType = loanType;
		this.loanAmount = loanAmount;
	}
	public void getLoan(String accId, Loan loan) throws SQLException {
		service.getLoan(accId, loan);
	}
	
	public void showLoanDetails(String accId, String loanId) throws SQLException{
		service.showLoanDetails(accId, loanId);
	}

}
