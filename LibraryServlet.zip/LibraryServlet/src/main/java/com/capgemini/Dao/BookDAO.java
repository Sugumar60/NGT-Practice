/**
 * 
 */
package com.capgemini.Dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.model.Book;
import com.capgemini.model.Library;

public class BookDAO {
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("servlet-jpa");
	EntityManager em = factory.createEntityManager();

	public void addLibrary(Library library) {
		em.getTransaction().begin();
		em.persist(library);
		em.getTransaction().commit();	
	}
	
	public Library findBook(String libraryId) { 
		return em.find(Library.class,libraryId); 
	}
	
	public Book findBookById(String bookId) {
		
		return em.find(Book.class,bookId);
	}

    public Book updateBookDetails(String bookId, String bookName, String author, String publisher) {
        Book book = findBookById(bookId);
		em.getTransaction().begin();
	    book.setBookName(bookName);
		book.setAuthor(author);
		book.setPublisher(publisher);
		em.getTransaction().commit();
		return book;
	}

    public void deleteBookById(String libraryId) {
		em.getTransaction().begin();
		Library library = findBook(libraryId); em.remove(library);
		em.getTransaction().commit();
	}

	

}
