package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.Dao.BookDAO;
import com.capgemini.model.Book;
import com.capgemini.model.Library;

@WebServlet("/searchBook")
public class SearchBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	BookDAO dao = new BookDAO();
      
    public SearchBook() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
        Library lib = dao.findBook(request.getParameter("libraryId"));
		if(lib!=null){
			out.println("Library Id  :"+lib.getLibraryId());
			out.print("<br>");
			out.println("Library Name:"+lib.getLibraryName());
			out.print("<br>");
		}
		
		Book b = dao.findBookById(request.getParameter("bookId"));
		if(b!=null) { 
			out.println("Book Id          : "+b.getBookId());out.print("<br>");
		    out.println("Book Name        : "+b.getBookName());out.print("<br>");
		    out.println("Author of Book   : "+b.getAuthor());out.print("<br>");
		    out.println("Publisher of Book: "+b.getPublisher());
		}else
		    out.println("Enter the correct BookId");
	}
}
