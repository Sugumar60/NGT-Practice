package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.Dao.BookDAO;
import com.capgemini.model.Book;
import com.capgemini.model.Library;

@WebServlet("/addBook")
public class AddBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

    BookDAO dao=new BookDAO();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String libraryId=request.getParameter("libraryId");
    	String libraryName=request.getParameter("libraryName");
    	String bookId=request.getParameter("bookId");
		String bookName=request.getParameter("bookName");
		String author=request.getParameter("author");
		String publisher=request.getParameter("publisher");
	    String bookId2=request.getParameter("bookId2");
		String bookName2=request.getParameter("bookName2");
		String author2=request.getParameter("author2");
		String publisher2=request.getParameter("publisher2");
		PrintWriter out=response.getWriter();
		out.println(libraryId);
		out.println(libraryName);
		out.println(bookId);
		out.println(bookName);
		out.println(author);
		out.println(publisher);
		out.println(bookId2);
		out.println(bookName2);
		out.println(author2);
		out.println(publisher2);
		
		Library library=new Library(libraryId, libraryName);
		Book book1=new Book(bookId, bookName, author, publisher, library);
		Book book2=new Book(bookId2, bookName2, author2, publisher2, library);
		library.getBook().add(book1);
		library.getBook().add(book2);
		dao.addLibrary(library);
		out.println("Books are added in library");		
	}

}
