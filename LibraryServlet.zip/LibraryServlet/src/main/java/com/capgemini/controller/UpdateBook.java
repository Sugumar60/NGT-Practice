package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.Dao.BookDAO;
import com.capgemini.model.Book;

@WebServlet("/updateBook")
public class UpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	BookDAO dao = new BookDAO();
	
    public UpdateBook() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String bookId = request.getParameter("bookId");
		String bookName = request.getParameter("bookName");
		String author = request.getParameter("author");
		String publisher = request.getParameter("publisher");
		dao.findBookById(bookId);
        Book updatedBook = dao.updateBookDetails(bookId,bookName,author,publisher);
		out.println("Book Name          : "+updatedBook.getBookName());out.print("<br>");
		out.println("Book Author        : "+updatedBook.getAuthor());out.print("<br>");
		out.println("Book Publisher Name: "+updatedBook.getPublisher());out.print("<br>");		
	}

}
