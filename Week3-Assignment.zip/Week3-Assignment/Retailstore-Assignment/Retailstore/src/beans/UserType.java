package beans;

public enum UserType {
	EMPLOYEE,AFFILIATE,CUSTOMER;
}
