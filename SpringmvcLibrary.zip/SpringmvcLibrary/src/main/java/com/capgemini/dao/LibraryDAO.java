package com.capgemini.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.transaction.Transactional;

import com.capgemini.model.Book;
import com.capgemini.model.Library;

@Transactional
public class LibraryDAO {
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("library");
	EntityManager manager = factory.createEntityManager();
	
	public void addLibrary(Library library) {
		manager.persist(library);
	}
	
	public Library findBook(String libraryId) {
		return manager.find(Library.class, libraryId);
	}
	
	public Book findBookById(String bookId) {
		return manager.find(Book.class, bookId);
	}
	
	public Book updateBook(String bookId, String bookName, String author, String publisher) {
		Book book =  findBookById(bookId);
		book.setBookName(bookName);
		book.setAuthor(author);
		book.setPublisher(publisher);
		return book;
	}
	
	public void deleteBookById(String bookId) {
		Book book = findBookById(bookId);
		manager.remove(book);
	}
}
