package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.dao.LibraryDAO;
import com.capgemini.model.Book;
import com.capgemini.model.Library;

@Controller
public class LibraryController {
	
	LibraryDAO dao = new LibraryDAO();
	
	@RequestMapping("/addBook")
	public void addBook(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String libraryId=request.getParameter("libraryId");
    	String libraryName=request.getParameter("libraryName");
    	String bookId=request.getParameter("bookId");
		String bookName=request.getParameter("bookName");
		String author=request.getParameter("author");
		String publisher=request.getParameter("publisher");
	    String bookId2=request.getParameter("bookId2");
		String bookName2=request.getParameter("bookName2");
		String author2=request.getParameter("author2");
		String publisher2=request.getParameter("publisher2");
		PrintWriter out=response.getWriter();
		out.println(libraryId);
		out.println(libraryName);
		out.println(bookId);
		out.println(bookName);
		out.println(author);
		out.println(publisher);
		out.println(bookId2);
		out.println(bookName2);
		out.println(author2);
		out.println(publisher2);
		
		Library library=new Library(libraryId, libraryName);
		Book book1=new Book(bookId, bookName, author, publisher, library);
		Book book2=new Book(bookId2, bookName2, author2, publisher2, library);
		library.getBook().add(book1);
		library.getBook().add(book2);
		dao.addLibrary(library);
		out.println("Books are added in library");
	}

	@RequestMapping("/deleteBook")
	public void deleteBook(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		dao.deleteBookById(request.getParameter("deletelid"));
		out.println("Library  ID "+request.getParameter("deletelid")+" deleted. ");
	}
	
	@RequestMapping("/searchBook")
	public void searchBook(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
        Library lib = dao.findBook(request.getParameter("libraryId"));
		if(lib!=null){
			out.println("Library Id  :"+lib.getLibraryId());
			out.print("<br>");
			out.println("Library Name:"+lib.getLibraryName());
			out.print("<br>");
		}
		
		Book b = dao.findBookById(request.getParameter("bookId"));
		if(b!=null) { 
			out.println("Book Id          : "+b.getBookId());out.print("<br>");
		    out.println("Book Name        : "+b.getBookName());out.print("<br>");
		    out.println("Author of Book   : "+b.getAuthor());out.print("<br>");
		    out.println("Publisher of Book: "+b.getPublisher());
		}else
		    out.println("Enter the correct BookId");
	}
	
	@RequestMapping("/updateBook")
	public void updateBook(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String bookId = request.getParameter("bookId");
		String bookName = request.getParameter("bookName");
		String author = request.getParameter("author");
		String publisher = request.getParameter("publisher");
		dao.findBookById(bookId);
        Book updatedBook = dao.updateBook(bookId,bookName,author,publisher);
		out.println("Book Name          : "+updatedBook.getBookName());out.print("<br>");
		out.println("Book Author        : "+updatedBook.getAuthor());out.print("<br>");
		out.println("Book Publisher Name: "+updatedBook.getPublisher());out.print("<br>");
	}
}
