package com.capgemini.sort;

import java.util.Comparator;

import com.capgemini.model.Address;
import com.capgemini.model.Employee;

public class EmployeeSort {
	
	public static final Comparator<Employee> COMPARE_BY_EMPLOYEE_ID = Comparator.comparing(Employee::getEmployeeId);
	public static final Comparator<Employee> COMPARE_BY_FIRST_NAME = Comparator.comparing(Employee::getFirstName);
	public static final Comparator<Employee> COMPARE_BY_LAST_NAME = Comparator.comparing(Employee::getLastName);
	public static final Comparator<Employee> COMPARE_BY_SALARY = Comparator.comparing(Employee::getSalary);
	public static final Comparator<Employee> COMPARE_BY_DEPARTMENT = new Comparator<Employee>() {	
		public int compare(Employee emp1, Employee emp2) {		
			return emp1.getDepartment().getDepartmentId().compareTo(emp2.getDepartment().getDepartmentId());
		}		
	};
	public static final Comparator<Address>  COMPARE_BY_ADDRESS = Comparator.comparing(Address::getAddressId);
}
