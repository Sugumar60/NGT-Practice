package com.capgemini.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.model.Address;
import com.capgemini.model.Department;
import com.capgemini.model.Employee;
import com.capgemini.sort.EmployeeSort;
import com.capgemini.sort.EmployeeValidate;

public class EmployeeMain {

	public static void main(String[] args) {
		
		Map<Employee,String> hm = new HashMap<Employee, String>(); 
		Set<Address> setOfAddress = new HashSet<Address>();
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			System.out.println("PLEASE SELECT YOUR ACTION \n1. Add Employee \n2. Sort By Employee ID \n3. Sort By First Name \n4. Sort By Last Name \n5. Sort By Salary \n6. Sort By Address \n7. Sort By Department \n8. Exit");
			switch(sc.next()) {
			
			case "1": 
				Employee emp = new Employee();
				Department dept = new Department();
				EmployeeValidate validate = new EmployeeValidate();
				String empId, firstName, lastName;
				double salary = 0.0;
				System.out.println("Enter Employee ID [i.e: 12345_FS]: ");
		        empId = sc.next();
		        if(validate.validateEmployeeId(empId))
		        	emp.setEmployeeId(empId);
		        else {
		        	System.out.println("Please enter valid Employee ID.");
		    	    break;
		        }
			    System.out.println("Enter your first name: ");
			    firstName = sc.next();
			    if(validate.validateFirstName(firstName)) 
			    	emp.setFirstName(firstName);
			    else {
			    	System.out.println("Error! Please enter valid First Name");
					break;
				}
		 		System.out.println("Enter your last name: ");
		 		lastName= sc.next();
		 		if(validate.validateLastName(lastName))
				  emp.setLastName(lastName);
		 		else {
		 			System.out.println("Please enter valid Last Name");
		 			break;
		 		}
				System.out.println("Enter your salary [i.e: 20,000 - 5,00,000]: ");
				salary = sc.nextDouble();
				if(validate.validateSalary(salary))
					emp.setSalary(salary);
				else {
					System.out.println("Error! Please enter valid salary");
					break;
				}
				System.out.println("Enter your date of joining: ");
				emp.setDateOfJoining(sc.next());
				System.out.println("Enter Department ID");
				dept.setDepartmentId(sc.next());
				System.out.println("Enter Department Name");
		        dept.setDepartmentName(sc.next());
				System.out.println("Enter Department Location");
				dept.setLocation(sc.next());
				emp.setDepartment(dept);
				System.out.println("Please enter the number of addresses to be stored");
				int noOfAddress= sc.nextInt();
				for(int i=0;i < noOfAddress; i++) {
					Address address = new Address();
				    System.out.println("Please Enter Address ID:");
				 	address.setAddressId(sc.next());
					System.out.println("Please Enter Address Line 1:");
				    address.setAddressLine1(sc.nextLine());
					System.out.println("Please Enter City:");
					address.setCity(sc.next());
				    System.out.println("Please Enter State:");
					address.setState(sc.next());
					setOfAddress.add(address);
				}
				emp.setAddress(setOfAddress);
			    hm.put(emp, emp.getEmployeeId());
			    System.out.println("Details saved.");
			    break;
		    
			case "2": 
				List<Employee> list = new ArrayList(hm.keySet());
				Collections.sort(list, EmployeeSort.COMPARE_BY_EMPLOYEE_ID); 
		        if(list.isEmpty())
		        	System.out.println("Please check your inputs");
		        else {
		        	list.forEach(System.out::println);
		            break;
				}        
				break;        
				    
		    case "3":
		    	List<Employee> list2 = new ArrayList(hm.keySet());
			    Collections.sort(list2, EmployeeSort.COMPARE_BY_FIRST_NAME); 
			    if(list2.isEmpty())
			    	System.out.println("Please check your inputs");
			    else {
			    	list2.forEach(System.out::println);
					break;
		         }
				 break;
				 
		    case "4":
		    	List<Employee> list3 = new ArrayList(hm.keySet());
		    	Collections.sort(list3, EmployeeSort.COMPARE_BY_LAST_NAME); 
		        if(list3.isEmpty())
		        	System.out.println("Please check your inputs");
		        else {
		        	list3.forEach(System.out::println);
		        	break;
	         	}
			    break;
			   
		    case "5":
		    	List<Employee> list4 = new ArrayList(hm.keySet());
			    Collections.sort(list4, EmployeeSort.COMPARE_BY_SALARY); 
				if(list4.isEmpty())
					System.out.println("Please check your inputs");
				else {
					list4.forEach(System.out::println);
					break;
			    }
				break;      
					
			 case "6": 
				 List<Address> list5 = new ArrayList<Address>(setOfAddress);
			     Collections.sort(list5, EmployeeSort.COMPARE_BY_ADDRESS); 
			     if(setOfAddress.isEmpty())
			    	 System.out.println("Please check your inputs");
				 else{
					 setOfAddress.forEach(System.out::println);
					 break;
			     }
			     break;
			     
			 case "7":
				 List<Employee> list6 = new ArrayList(hm.keySet());
				 Collections.sort(list6, EmployeeSort.COMPARE_BY_DEPARTMENT); 
				 if(list6.isEmpty())
					 System.out.println("Please check your inputs");
				 else {
					 list6.forEach(System.out::println);
				     break;
		         }
				 break;
				        
			 case "8":
				 System.out.println("Thank you for using our Application.");
		         System.exit(0);
			   
			 default:
				 System.out.println("Choose the valid Action");
		     }
		}	
	}
}
