package com.sport.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.sport.model.Match;
import com.sport.model.Player;
import com.sport.model.Team;
import com.sport.service.MatchBO;
import com.sport.service.PlayerBO;
import com.sport.service.TeamBO;

public class AppMain {

	public static void main(String[] args) throws IOException {

		String data;
		Scanner sc = new Scanner(System.in);
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		PlayerBO playerBO = new PlayerBO();
		TeamBO teamBO = new TeamBO();
		MatchBO matchBO = new MatchBO();
		Player[] players;
		Team[] teams;
		Match[] matches;
		
		Player player;
		int playerCount,teamCount,matchCount;
		System.out.println("Enter the Player count:");
		playerCount = sc.nextInt();
		players = new Player[playerCount];
		for(int i=0,j=1; i<playerCount; i++,j++){
			System.out.println("Enter player "+j+" details");
			data = reader.readLine();
			player = playerBO.createPlayer(data);
			players[i] = player;
		}
		System.out.println("Enter team count");
		teamCount = sc.nextInt();
		teams = new Team[teamCount];
		for(int i=0,j=1; i<teamCount; i++,j++) {
			System.out.println("Enter team "+j+" details");
			data = reader.readLine();
			teams[i] = teamBO.createTeam(data, players);
		}
		System.out.println("Enter match count");
		matchCount = sc.nextInt();
		matches = new Match[matchCount];
		for(int i=0,j=1; i<matchCount; i++,j++) {
			System.out.println("Enter match "+j+" details");
			data = reader.readLine();
			matches[i] = matchBO.createMatch(data, teams);
		}
		boolean response = true;
		do {
			System.out.println("Menu:  \n1) Find Team \n2) Find all the matches of the specific team \nType 1 or 2 \nEnter your choice");
			switch(sc.nextInt()) {
			case 1:
				System.out.println("Enter match date");
				data = reader.readLine();
				Team t[] = matchBO.findTeam(data, matches);
				System.out.println("Team \n"+t[0].getName()+","+t[1].getName());
				break;
			case 2:
				System.out.println("Match Details \nEnter team Name");
				data = reader.readLine();
				matchBO.findAllMatchesOfTeam(data, matches);
				break;
			default:
				System.out.println("Choose a valid action");
			}
			
			System.out.println("Do you want to continue? Type  Yes or No");
			String y = "Yes";
			data = sc.next();
			if(data.equalsIgnoreCase(y))
				response = true;
			else {
				sc.close();
				response = false;
			}
		}while(response);
	}

}
