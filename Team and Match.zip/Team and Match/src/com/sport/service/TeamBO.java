package com.sport.service;

import com.sport.model.Player;
import com.sport.model.Team;

public class TeamBO {
	
	public Team createTeam(String data, Player[] playerList) {
		String info[] = data.split(",");
		Team team = new Team();
		team.setName(info[0]);
		for(Player player : playerList) {
			if(player.getName().equalsIgnoreCase(info[1]))
				team.setPlayer(player);
		}
		return team;
	}
}
