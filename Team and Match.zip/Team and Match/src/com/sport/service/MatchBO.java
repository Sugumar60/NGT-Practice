package com.sport.service;

import com.sport.model.Match;
import com.sport.model.Team;

public class MatchBO {

	public Match createMatch(String data, Team[] teamList) {
		String info[] = data.split(",");
		Match match = new Match();
		match.setDate(info[0]);
		for(Team team : teamList) {
			if(team.getName().equalsIgnoreCase(info[1]))
				match.setTeamOne(team);
		}
		for(Team team : teamList) {
			if(team.getName().equalsIgnoreCase(info[2]))
				match.setTeamTwo(team);
		}
		match.setVenue(info[3]);
		return match;
	}
	
	public Team[] findTeam(String matchDate, Match[] matchList) {
		Team teams[] = new Team[2];
		for(Match match : matchList) {
			if(match.getDate().equals(matchDate)) {
				teams[0] = match.getTeamOne();
				teams[1] = match.getTeamTwo();
			}
		}
		return teams;
	}
	
	public void findAllMatchesOfTeam(String teamName, Match[] matchList) {
		for(Match match : matchList) {
			if((match.getTeamOne().getName().equalsIgnoreCase(teamName)) || (match.getTeamTwo().getName().equalsIgnoreCase(teamName)))
				System.out.println(match);
			
		}
	}
}
