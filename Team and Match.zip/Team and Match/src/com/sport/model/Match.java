package com.sport.model;

public class Match {
	
	private  String date;
	private Team teamOne;
	private Team teamTwo;
	private String Venue;
	private Team team;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Team getTeamOne() {
		return teamOne;
	}
	public void setTeamOne(Team teamOne) {
		this.teamOne = teamOne;
	}
	public Team getTeamTwo() {
		return teamTwo;
	}
	public void setTeamTwo(Team teamTwo) {
		this.teamTwo = teamTwo;
	}
	public String getVenue() {
		return Venue;
	}
	public void setVenue(String venue) {
		Venue = venue;
	}
	public Team getTeam() {
		return team;
	}
	public void setTeam(Team team) {
		this.team = team;
	}
	public Match(String date, Team teamOne, Team teamTwo, String venue, Team team) {
		super();
		this.date = date;
		this.teamOne = teamOne;
		this.teamTwo = teamTwo;
		this.Venue = venue;
		this.team = team;
	}
	public Match() {
		super();
	}
	@Override
	public String toString() {
		return String.format("Date \t \tTeamOne \t TeamTwo \t Venue \n%s %10s %15s %30s",date,teamOne.getName(),teamTwo.getName(),Venue +"\n");
	}
	

}
