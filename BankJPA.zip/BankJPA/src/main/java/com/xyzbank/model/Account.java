package com.xyzbank.model;

import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import com.xyzbank.service.BankService;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Account { 
	@Id
	private String accountId;
	@Column(nullable = false)
	private String accountName;
	private String address;
	private double depositAmount;
	private Loan loan;
	
	public Loan getLoan() {
		return loan;
	}
	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	BankService service = new BankService();
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}
		
	public Account() {
		super();
	}
	public Account(String accountId, String accountName, String address, double depositAmount) {
		this.accountId = accountId;
		this.accountName = accountName;
		this.address = address;
		this.depositAmount = depositAmount;
	}
	
	
	public void showDetails(String id) throws SQLException {
		service.showAccountDetails(id);
	}
	
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountName=" + accountName + ", address=" + address
				+ ", depositAmount=" + depositAmount + "]";
	}
	
	
	
	

}
