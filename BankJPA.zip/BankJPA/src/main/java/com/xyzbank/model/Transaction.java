package com.xyzbank.model;

import java.sql.SQLException;

import javax.persistence.Entity;

import com.xyzbank.service.BankService;
@Entity
public class Transaction extends Loan {
	
	private double amount;
	BankService service = new BankService();

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public double depositAmount(String accId, double damt) throws SQLException {
		return service.depositAmount(accId, damt);
	}
	
	public double withdrawAmount(String accId, double wamt) throws SQLException {
		return service.withdrawAmount(accId, wamt);
	}
	
	public void payLoan(String loanId, String accId, double amt) throws SQLException {
		service.payLoan(loanId, accId, amt);
	}

}
