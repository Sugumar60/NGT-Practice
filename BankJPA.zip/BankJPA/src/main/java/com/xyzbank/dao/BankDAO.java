package com.xyzbank.dao;
import java.sql.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.xyzbank.model.Account;
import com.xyzbank.model.Loan;


public class BankDAO {
	
	double amount = 0.0;
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("bankjpa");
	EntityManager em = factory.createEntityManager();
	
	public void createAccount(Account acc)  {
		em.getTransaction().begin();
		em.persist(acc);
		em.getTransaction().commit();
	}
	
	public Account getDetails(String id) {
		
		return em.find(Account.class, id);		
	}
	
	public void getLoan(String accId, Loan loan){
		Account acc = em.find(Account.class, accId);
		em.getTransaction().begin();
		acc.setDepositAmount(acc.getDepositAmount()+loan.getLoanAmount());
		System.out.println("loan amount credited to your account.");
		acc.setLoan(loan);
		em.persist(acc);
		em.getTransaction().commit();
		System.out.println("your new balance is "+acc.getDepositAmount());
	}
	
	public void showLoanDetails(String accId, String loanId) throws SQLException {
		Account acc = em.find(Account.class, accId);
		System.out.println("Loan Id     : " + acc.getLoan().getLoanId());
		System.out.println("Loan Type   : " + acc.getLoan().getLoanType().toString());
		System.out.println("Loan Amount : " + acc.getLoan().getLoanAmount());
		  
		
	}
	
	public double depositAmount(String accId, double damt) {
		Account acc= em.find(Account.class, accId);
		amount =  acc.getDepositAmount() + damt;
		acc.setDepositAmount(amount);
		em.getTransaction().begin();
		em.persist(acc);
		em.getTransaction().commit();
		return  amount;
	}
	
	public double withdrawAmount(String accId, double wamt) {
		Account acc= em.find(Account.class, accId);
		if(acc.getDepositAmount() <= wamt) {
			em.getTransaction().begin();
			amount =  acc.getDepositAmount() - wamt;
			acc.setDepositAmount(amount);
			em.persist(acc);
			em.getTransaction().commit();
			System.out.println("Withdrawn Successfully!!");
		}
		else
			System.out.println("Insufficient balance.");
		return amount;
	}
	
	public void payLoan(String loanId,  String accId, double amt) {
		Account acc = em.find(Account.class, accId);
		if((acc.getLoan().getLoanAmount()<=amt) && (acc.getDepositAmount()>=amt)) {
			em.getTransaction().begin();
			amount = acc.getLoan().getLoanAmount()-amt;
			acc.getLoan().setLoanAmount(amount);
			acc.setDepositAmount(acc.getDepositAmount()-amt);
			em.persist(acc);
			em.getTransaction().commit();
			System.out.println("Amount debited from your account.");
			System.out.println("Your current balance is Rs." + acc.getDepositAmount());
			System.out.println("Still you need to pay Rs." + acc.getLoan().getLoanAmount());
		}
		else
			System.out.println("Invalid amount");
		
	}

	public void showAccountDetails(String accId) {
		Account acc = em.find(Account.class, accId);
		System.out.println("====================== \nAccount Details \n======================");
		System.out.println("Account Id     : " + acc.getAccountId());
		System.out.println("Account Name   : " + acc.getAccountName());
		System.out.println("Adress         : " + acc.getAddress());
		System.out.println("Account Balance: " + acc.getDepositAmount()); 
	}
	

}
